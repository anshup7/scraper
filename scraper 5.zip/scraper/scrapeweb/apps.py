from django.apps import AppConfig


class ScrapewebConfig(AppConfig):
    name = 'scrapeweb'
